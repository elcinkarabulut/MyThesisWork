package com.example.elcinkarabulut.kamera;

/**
 * Created by ElcinKarabulut on 4.4.2016.
 */
public interface TranslateCallback {
 
    public void onSuccess(String result);
}
